import React ,{useState, useEffect} from "react";
import "./QuotationView.css"
import NavBar from "./NavBar";
import  './NavBar.css'


const QuotationView = ()=>{
    const [quoteResponse, setQuoteResponse] = useState();

    const getAllQuotes=()=>{
        fetch(`http://localhost:8082/quotes/all`)
        .then((response) => response.json())
        .then((data)=>{
            setQuoteResponse(data[Math.floor(Math.random() * data.length)]);
            // console.log(data[Math.floor(Math.random() * data.length)]);
            
            
        })
        .catch((error) => console.error("data not found", error));
    };

    useEffect(() => {
        getAllQuotes(); 
      }, []);
      console.log(quoteResponse);

    return(
      <div>
        <div>
        <NavBar/>
        </div>
        <div className="quote-block">
<div className="quote-container">
      {quoteResponse ? (
       
          <div className="quote-box">
            <p className="quote-text">"{quoteResponse.quote}"</p>
            <p className="author">- {quoteResponse.author}</p> 
          </div>
        
      ) : (
        <p>Loading quotes...</p> 
      )}
    </div>
      </div>

      </div>
      
        
    );
}
export default QuotationView;