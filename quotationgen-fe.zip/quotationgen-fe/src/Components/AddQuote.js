import React, { useState }  from "react";
import "./AddQuote.css"

const  AddQuote = ()=>{

  const [quoteText, setQuoteText] =useState();
  const [authorText, setAuthorText] = useState();
  const [categoryText, setCategoryText] = useState();

  const handleSubmit = async (e)=>{
    e.preventDefault();
    const quoteData=  {
      quote:quoteText,
      author:authorText,
      category:categoryText,
    };

    const response  = await fetch(`http://localhost:8082/quotes/add`,{
      method:'POST',
      headers:{
        'Content-Type':'application/json',
      },
      body:JSON.stringify(quoteData),
    })

    console.log(response.status)
  }


    return(
       <div>
         <h2>Add a Quote</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="quote">Quote:</label>
          <input
            type="text"
            id="quote"
            value={quoteText}
            onChange={(e) => setQuoteText(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="author">Author:</label>
          <input
            type="text"
            id="author"
            value={authorText}
            onChange={(e) => setAuthorText(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="category">category:</label>
          <input
            type="text"
            id="category"
            value={categoryText}
            onChange={(e) => setCategoryText(e.target.value)}
            required
          />
        </div>
        <button type="submit">Add Quote</button>
      </form>
      {/* {error && <p style={{ color: 'red' }}>{error}</p>} */}
       </div>
    );
}
export default AddQuote;