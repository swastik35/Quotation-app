import react from "react";
import  './NavBar.css'
import { useNavigate } from "react-router-dom";





const NavBar= ()=>{
    const navigate = useNavigate();

    const handleClick = ()=>{
        navigate('/add')
    }

return (
    <div className="nav-bar">
        <button className="btn" onClick={handleClick}>ADD</button>
        
    </div>
);

}

export default NavBar;