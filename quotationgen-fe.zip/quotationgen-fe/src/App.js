import QuotationView from "./Components/QuotationView";
import AddQuote from "./Components/AddQuote";
import React from "react";

import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import reactRouterDom from "react-router-dom";


function App() {
  return (
    
    <Router>
      <main>    
        <Routes>
          <Route path="/" element={<QuotationView />} />
          <Route path="/add" element={<AddQuote />} />
          
          {/* The Navigate component replaces the Redirect component */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
    </Router>
  );
}

export default App;
